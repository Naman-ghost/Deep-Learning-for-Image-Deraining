from datasets.ImgLIPDset import ImgLIPDset
from PIL import Image
import os
import numpy as np
import torch

class ImgLIPNfreqsKshot:
    """
    Implements the N-frequency-K-shot task sampling logic.
    This class creates 'episodes' or 'tasks' for the meta-learning loop.
    """
    def __init__(self, root_dir, batch_size, n_freqs, k_shot, k_query, patch_size, imchannel=3):
        # Load the base dataset
        imgDset_spt = ImgLIPDset(root_dir, mode='train')
        imgDset_qry = ImgLIPDset(root_dir, mode='test')
        
        # Organize images by their cluster labels
        self.dict_spt = self._organize_by_label(imgDset_spt)
        self.dict_qry = self._organize_by_label(imgDset_qry)

        self.batch_size = batch_size
        self.n_freqs = n_freqs
        self.k_shot = k_shot
        self.k_query = k_query
        self.patch_size = (patch_size, patch_size) if isinstance(patch_size, int) else patch_size
        self.imchannel = imchannel
        
        self.indexes = {'train': 0, 'test': 0}
        self.datasets = {'train': self.dict_spt, 'test': self.dict_qry}
        
        # Pre-cache some data episodes to speed up the training loop
        self.datasets_cache = {
            'train': self.load_data_cache(self.datasets['train']),
            'test': self.load_data_cache(self.datasets['test'])
        }
        self.total_train_samples = len(imgDset_spt)

    def _organize_by_label(self, dset):
        organized_data = {}
        for (img_path, label) in dset:
            if label in organized_data:
                organized_data[label].append(img_path)
            else:
                organized_data[label] = [img_path]
        return organized_data

    def _process_image_pair(self, clean_path):
        # Derive the rainy path from the clean path
        # This matches the structure created by your dummy data script
        rain_path = clean_path.replace('clean', 'rain').replace('norain', 'rain')
        
        clean_img = Image.open(clean_path)
        noise_img = Image.open(rain_path)
        
        # Convert to arrays, normalize to [0, 1], and change to (C, H, W) format
        c = np.transpose(np.array(clean_img), (2, 0, 1)) / 255.0
        n = np.transpose(np.array(noise_img), (2, 0, 1)) / 255.0
        
        return c.astype('f4'), n.astype('f4')

    def load_data_cache(self, dset):
        # Task sizes: Support set and Query set
        setsz = self.k_shot * self.n_freqs
        qyrsz = self.k_query * self.n_freqs
        data_cache = []
        
        for _ in range(10): # Generate 10 episodes at a time
            batch_spts_x, batch_spts_y, batch_qrys_x, batch_qrys_y = [], [], [], []
            
            for _ in range(self.batch_size):
                s_x = np.zeros((setsz, self.imchannel, *self.patch_size), dtype='f4')
                s_y = np.zeros((setsz, self.imchannel, *self.patch_size), dtype='f4')
                q_x = np.zeros((qyrsz, self.imchannel, *self.patch_size), dtype='f4')
                q_y = np.zeros((qyrsz, self.imchannel, *self.patch_size), dtype='f4')
                
                # Pick N random texture clusters
                available_labels = list(dset.keys())
                selected_freqs = np.random.choice(available_labels, self.n_freqs, replace=False)
                
                for i, freq in enumerate(selected_freqs):
                    # Pick K patches for Support and K patches for Query from this cluster
                    all_imgs = dset[freq]
                    selected_imgs = np.random.choice(all_imgs, self.k_shot + self.k_query, replace=False)
                    
                    for j, img_p in enumerate(selected_imgs[:self.k_shot]):
                        s_y[i*self.k_shot+j], s_x[i*self.k_shot+j] = self._process_image_pair(img_p)
                        
                    for j, img_p in enumerate(selected_imgs[self.k_shot:]):
                        q_y[i*self.k_query+j], q_x[i*self.k_query+j] = self._process_image_pair(img_p)
                
                batch_spts_x.append(s_x)
                batch_spts_y.append(s_y)
                batch_qrys_x.append(q_x)
                batch_qrys_y.append(q_y)
            
            data_cache.append([
                np.array(batch_spts_x), np.array(batch_spts_y), 
                np.array(batch_qrys_x), np.array(batch_qrys_y)
            ])
            
        return data_cache

    def next(self, mode='train'):
        # Cycle through the cached episodes
        if self.indexes[mode] >= len(self.datasets_cache[mode]):
            self.indexes[mode] = 0
            self.datasets_cache[mode] = self.load_data_cache(self.datasets[mode])
        
        current_batch = self.datasets_cache[mode][self.indexes[mode]]
        self.indexes[mode] += 1
        return current_batch
    