import torch.utils.data as data
import os
from PIL import Image
import numpy as np

class ImgLIPDset(data.Dataset):
    def __init__(self, root_dir, mode='train'):
        self.root_dir = root_dir
        self.all_items = traverse_freqs(root_dir, mode) 
        self.idx_freqs = index_freqs(self.all_items)  
    
    def __getitem__(self, index):
        item = self.all_items[index]
        img = os.path.join(item[1], item[0])
        freq = self.idx_freqs[item[1].strip('/').split('/')[-1]]
        return img, freq  
    
    def __len__(self):
        return len(self.all_items)

def traverse_freqs(root_dir, mode='train', token='clean'): 
    ret = []
    dset_dir = os.path.join(root_dir, mode, token)
    for (root, dirs, files) in os.walk(dset_dir):
        for f in files:
            if (f.endswith('png')): 
                ret.append([f, root])
    print('== Found %d items for %s' % (len(ret), mode))
    return sorted(ret, key=lambda x: x[1])

def index_freqs(items):
    idx = {}
    for item in items:
        freq_name = item[1].strip('/').split('/')[-1]
        if freq_name not in idx:
            idx[freq_name] = len(idx) 
    print('== Found %d freqs' % len(idx))
    return idx

class TestDataset(data.Dataset):
    def __init__(self, dataset_config, **kwargs):
        self.type = kwargs['type']
        if self.type != 'noise':
            self.clean_dir, self.noise_dir = kwargs['clean_dir'], kwargs['noise_dir']
        else:
            self.clean_dir = kwargs['clean_dir']
            self.sigmas = kwargs['sigmas']
        self.name = kwargs['dataset']
        self.clean_format, self.noise_format, self.total_sampels, self.begin_idx = dataset_config[kwargs['dataset']]
    
    def __getitem__(self, index):
        if self.type != 'noise':
            clean_img = os.path.join(self.clean_dir, self.clean_format.format(index+self.begin_idx))
            noise_img = os.path.join(self.noise_dir, self.noise_format.format(index+self.begin_idx))
            clean_img, noise_img = Image.open(clean_img), Image.open(noise_img)
            clean_img = np.transpose(clean_img, (2, 0, 1))/255.0
            noise_img = np.transpose(noise_img, (2, 0, 1))/255.0
        else:
            clean_img = os.path.join(self.clean_dir, self.clean_format.format(index+self.begin_idx))
            clean_img = Image.open(clean_img)
            clean_img = np.transpose(clean_img, (2, 0, 1))/255.0
            sigma = np.random.choice(self.sigmas)
            noise_img = clean_img+np.random.randn(clean_img.shape)*(sigma/255.0)
        
        return clean_img.astype('f4'), noise_img.astype('f4')
    
    def __len__(self):
        return self.total_sampels